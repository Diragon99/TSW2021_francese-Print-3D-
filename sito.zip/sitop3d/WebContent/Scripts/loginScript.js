var logbtn=document.getElementById("loginbtn");
var validun=false;
var validpsw=false;
function verificaUserLogin(){
	x=0;
	x=document.getElementById("ulog").value.length;
	if(x<3 || x>10){
		logbtn.disabled=true
		validun=false;
		}
	else{
		validun=true;
		if(validpsw){
			document.getElementById("loginbtn").disabled=false;
			}
		}
}
function verificaPwd(){
	x=0
	x=document.getElementById("pwdlog").value.length;
	if(x<8||x>20){
		document.getElementById("loginbtn").disabled=true;
		validpsw=false;
		}
	else {
		validpsw=true;
		if(validun){
			document.getElementById("loginbtn").disabled=false;
		}
	}
}