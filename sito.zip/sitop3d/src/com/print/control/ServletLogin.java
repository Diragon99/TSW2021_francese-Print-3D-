package com.print.control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.print.model.*;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/loginServlet")
public class ServletLogin extends HttpServlet {


/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public void doGet(HttpServletRequest request, HttpServletResponse response) 
			           throws ServletException, java.io.IOException {
	String action = request.getParameter("action");
	if(action.equalsIgnoreCase("login")) {
		try{	    
			UserBean user = new UserBean();
			user.setUserName(request.getParameter("un"));
			user.setPassword(request.getParameter("pw"));
			user = UserDAO.doRetrieve(user);	 	    
			if (user.isValid())
			{  
				HttpSession session = request.getSession(true);
				session.setAttribute("currentSessionUser",user);
				String role="authUser";
				user.setUser_type(role);
				session.setAttribute("user", user);
				response.sendRedirect("catalogView.jsp");      		
			}  
			else { 
				response.sendRedirect("invalidLogin.jsp");
			}
		}
			
		catch (Throwable theException) 	    
		{
		System.out.println(theException); 
		}
	}
	else if(action.equalsIgnoreCase("logout")) {
		HttpSession session = request.getSession(false);
		session.removeAttribute("user");
		session.invalidate();
		response.sendRedirect("catalogView.jsp");
	}
	
}
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
}
	}