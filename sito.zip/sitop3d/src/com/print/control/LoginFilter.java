package com.print.control;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.print.model.UserBean;
@WebFilter("/product")
public class LoginFilter implements Filter{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		System.out.println("LOGIN FILTER INVOCATO");
		HttpServletRequest hrequest = (HttpServletRequest) request;
		HttpServletResponse hresponse = (HttpServletResponse) response; 
		System.out.println(hrequest.getRequestURI());
		if(request.getParameter("action")!=null) {
				if(request.getParameter("action").equalsIgnoreCase("checkout")) {
					HttpSession session = hrequest.getSession(false);
					boolean loggedIn = (session.getAttribute("currentSessionUser")!=null&&(((UserBean)session.getAttribute("currentSessionUser")).isValid()));
					if(!loggedIn){
						System.out.println("Redirect to login form");
						hresponse.sendRedirect(hrequest.getContextPath()+ "/loginPage.jsp");
					} else {
						chain.doFilter(request, response);
					}
				} else {
					chain.doFilter(request, response);
				}
		}
		else {
			chain.doFilter(request, response);
		}
	}
}